"""ZARA SNIPER Telegram bot."""
